from flask import Flask, render_template, url_for

app = Flask(__name__)


@app.route('/')
@app.route('/index')
def index():
    param = {}
    param["title"] = "q"
    return render_template('base.html', **param)


@app.route('/training/<prof>')
def training(prof):
    param = {}
    param["title"] = prof
    print(prof)
    if "инженер" in prof:
        q = 1
    else:
        q = 2
    param["img_name"] = q
    return render_template('training.html', **param)


@app.route('/list_prof/<t>')
def list_prof(t):
    param = {}
    param["list"] = ["инженер-исследователь", "пилот", "строитель", "экзоюиолог", "врач",
                     "инженер по терраформированию", "климатолог", "специалист по радиационной защите", "астрогеолог",
                     "гляциолог", "инженер жизнеобеспечения", "метеоролог", "оператор марсохода", "киберинженер",
                     "штурман", "пилот дронов"]
    if "ol" == t:
        q = 1
    elif "ul" == t:
        q = 2
    else:
        q = 3
    param["type"] = q
    print(q)
    return render_template('list_prof.html', **param)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
